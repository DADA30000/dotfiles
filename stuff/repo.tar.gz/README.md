# This is my personal .dotfiles repo  
Stuff down below are notes for myself, and don't use my configuration, it's bad :)  
Don't forget to change username in flake.nix!  
Don't forget to `git lfs install`  
`git reset --hard HEAD^` to delete 1 commit  
`git reset --hard HEAD~2` to delete 2 commits  
![screenshot](screenshot.png)
