#!/usr/bin/env bash
if [ -f ./check ]; then
  git rm ./stuff/repo.tar.gz
  tar --exclude=repo.tar.gz --exclude=nixpkgs.tar.zst* --exclude=*.mp4 -czvf ./stuff/repo.tar.gz ./*
else
  echo "change your working directory to dotfiles already"
fi
